[![Build Status](NOTE: Use something like Travis CI http://about.travis-ci.org/docs/user/getting-started/)

# Project NAME

Brief explanation of the project.

### Installation and usage

### Troubleshooting

### Development

To see what has changed in recent versions of __PROJECT__, see the [CHANGELOG]().

### Core Team Members

List of core team members

### Resources

### Other questions

Feel free to chat with the __PROJECT__ core team (and many other users) on IRC in the  [#project](irc://irc.freenode.net/project) channel on Freenode, or via email on the [Project mailing list]().

### Copyright

Copyright © __YEAR__ __NAME__. See [LICENSE]() for details.

Project is a member of the [OSS Manifesto](http://ossmanifesto.com/).
