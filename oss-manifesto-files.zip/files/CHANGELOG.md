# CHANGELOG

## 0.2.0 (unreleased)

## 0.1.6

  * Fix isuee

## 0.1.3

  * Fix issue
